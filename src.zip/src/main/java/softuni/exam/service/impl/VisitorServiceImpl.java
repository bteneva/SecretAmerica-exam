package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.VisitorImportDto;
import softuni.exam.models.dto.VisitorsRootImportDto;
import softuni.exam.models.entity.Attraction;
import softuni.exam.models.entity.Country;
import softuni.exam.models.entity.PersonalData;
import softuni.exam.models.entity.Visitor;
import softuni.exam.repository.AttractionRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.PersonalDataRepository;
import softuni.exam.repository.VisitorRepository;
import softuni.exam.service.VisitorService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

//ToDo - Implement all the methods

@Service
public class VisitorServiceImpl implements VisitorService {
    private static final String PATH = "src/main/resources/files/xml/visitors.xml";
    private final VisitorRepository visitorRepository;
    private final XmlParser xmlParser;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final CountryRepository countryRepository;
    private final PersonalDataRepository personalDataRepository;
    private final AttractionRepository attractionRepository;

    @Autowired
    public VisitorServiceImpl(VisitorRepository visitorRepository, XmlParser xmlParser, ModelMapper modelMapper, ValidationUtil validationUtil, CountryRepository countryRepository, PersonalDataRepository personalDataRepository, AttractionRepository attractionRepository) {
        this.visitorRepository = visitorRepository;
        this.xmlParser = xmlParser;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.countryRepository = countryRepository;
        this.personalDataRepository = personalDataRepository;
        this.attractionRepository = attractionRepository;
    }

    @Override
    public boolean areImported() {

        return this.visitorRepository.count() > 0;
    }

    @Override
    public String readVisitorsFileContent() throws IOException {

        return Files.readString(Path.of(PATH));
    }

    @Override
    public String importVisitors() {
        StringBuilder stringBuilder = new StringBuilder();

        // Parse the XML file into a DTO object
        VisitorsRootImportDto visitorsRootImportDto = this.xmlParser.fromFile(PATH, VisitorsRootImportDto.class);

        for (VisitorImportDto dto : visitorsRootImportDto.getVisitors()) {
            // Check if a visitor with the same firstName and lastName exists
            Optional<Visitor> visitorByFirstNameLastName = this.visitorRepository.findByFirstNameAndLastName(dto.getFirstName(), dto.getLastName());

            // You can check the unique fields like personal_number_id if that's part of the import
            Optional<Visitor> visitorByPersonalNumberId = this.visitorRepository.findByPersonalDataId(dto.getPersonalDataId());

            // If either of these exist or if the DTO is invalid, skip the import
            if (visitorByFirstNameLastName.isPresent() || visitorByPersonalNumberId.isPresent() || !this.validationUtil.isValid(dto)) {
                stringBuilder.append("Invalid visitor").append(System.lineSeparator());
                continue;
            }
            System.out.print(visitorByFirstNameLastName.get().getFirstName() + " ");
            System.out.print(visitorByPersonalNumberId.get().getPersonalDataId() + " ");

            // Map the DTO to the Visitor entity
            Visitor visitor = modelMapper.map(dto, Visitor.class);
            System.out.println("visitor.firstName: " + visitor.getFirstName()
                    + " visitor.lastName: " + visitor.getLastName()
                    + " visitor.getCountry: " + visitor.getCountry()
                    + " visitor.getAttraction: " + visitor.getAttraction()
                    + " visitor.getPersonalData: " + visitor.getPersonalDataId()
                    + " dto.getPersonalData: " + dto.getPersonalDataId()
                    + " dtoGetAttractionId: " + dto.getAttractionId()
                    + " dto.getCountryId: " + dto.getCountryId());


//            Optional<Attraction> attraction = this.attractionRepository.findById(dto.getAttractionId());
//            Optional<Country> country = this.countryRepository.findById(dto.getCountryId());
//            Optional<PersonalData> personalData = this.personalDataRepository.findById(dto.getPersonalDataId());
//
//            visitor.setCountry(country.get());
//            visitor.setAttraction(attraction.get());
//            visitor.setPersonalDataId(personalData.get());



//            Optional<Country> country = this.countryRepository.findById(dto.getCountryId());
//            if (country.isEmpty()) {
//                stringBuilder.append("Invalid visitor: Country not found").append(System.lineSeparator());
//                continue;
//            }
//
//            Optional<PersonalData> personalData = this.personalDataRepository.findById(dto.getPersonalData());
//            if (personalData.isEmpty()) {
//                stringBuilder.append("Invalid visitor: Personal data not found").append(System.lineSeparator());
//                continue;
//            }
//            visitor.setAttraction(attraction.get());
//             visitor.setCountry(country.get());
//             visitor.setPersonalData(personalData.get());
//
//
             this.visitorRepository.saveAndFlush(visitor);
//
//            // Add success message
           stringBuilder.append(String.format("Successfully imported visitor %s %s", dto.getFirstName(), dto.getLastName()))
                   .append(System.lineSeparator());
//
        }

        return stringBuilder.toString();
    }
}

