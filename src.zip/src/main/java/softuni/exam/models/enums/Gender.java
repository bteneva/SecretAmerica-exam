package softuni.exam.models.enums;

public enum Gender {
    M,
    F
}
